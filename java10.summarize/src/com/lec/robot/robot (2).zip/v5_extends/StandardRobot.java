package com.lec.robot.v5_extends;

public class StandardRobot extends Robot {

	public StandardRobot(String name, int qty) {
		super(name, qty);
	}

}
