package com.lec.robot.v5_extends;

public class CheapRobot extends Robot {

	public CheapRobot(String name, int qty) {
		super(name, qty);
	}

}
