package com.lec.robot.v5_extends;

public class SuperRobot extends Robot {

	public SuperRobot(String name, int qty) {
		super(name, qty);
	}

}
