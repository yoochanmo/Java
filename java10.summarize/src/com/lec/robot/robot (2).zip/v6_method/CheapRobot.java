package com.lec.robot.v6_method;

public class CheapRobot extends Robot {

	public CheapRobot(String name, int qty) {
		super(name, qty);
	}

}
