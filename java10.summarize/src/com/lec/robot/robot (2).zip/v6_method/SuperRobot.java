package com.lec.robot.v6_method;

public class SuperRobot extends Robot {

	public SuperRobot(String name, int qty) {
		super(name, qty);
	}

}
