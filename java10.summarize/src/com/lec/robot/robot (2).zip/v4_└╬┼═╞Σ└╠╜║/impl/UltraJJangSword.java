package com.lec.robot.v4_인터페이스.impl;

import com.lec.robot.v4_인터페이스.inter.InterSword;

public class UltraJJangSword implements InterSword {

	@Override
	public void sword() {
		System.out.println("울트라짱검이 있습니다!");		
	}

}
